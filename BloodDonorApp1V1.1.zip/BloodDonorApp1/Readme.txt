How to operate the blood donation system Using PHP and MySQL


1.Paste inside root directory(for xampp xampp/htdocs, for wamp wamp/www, for lamp var/www/HTML)

2.Open PHPMyAdmin (http://localhost/phpmyadmin)

3. Create a bbdms with the name bbdms

4. Import bbdms.sql file(given inside the zip package in the SQL file folder)

5. Run the script http://localhost/bbdms

Admin Credential

Username: admin
Password: 1234

Donor Credential
Register a new user.
Then later login